var msg;
msg="<p><code>The actual script is in external script file called common.js</code></p>";
function addNos(headVar,bodyVar)
{
	document.write(msg);
	 var a=headVar+bodyVar;
	 document.write("The sum of the variables <code>headVar</code> and <code>bodyVar</code> is "+("<b>"+a+"</b>"));
}