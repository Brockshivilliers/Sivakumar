package model;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PizzaOrderDao {
	static EntityManagerFactory emf=Persistence.createEntityManagerFactory("ORDER");
	static EntityManager entityManager=emf.createEntityManager();
	public void addOrder(PizzaOrder order) {
		entityManager.persist(order);
	}
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}
	
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		//PizzaOrder po=new PizzaOrder();
		PizzaOrderDao pdao=new PizzaOrderDao();
		int price=100;
		System.out.println("Enter the Pizza Type small or large");
		String pizzaType=sc.next();
		if(pizzaType.equals("small"))
		{
			price+=20;
		}
		else if(pizzaType.equals("large"))
		{
			price+=50;
		}
		
		System.out.println("Enter the Extra Cheese you Want or Not Type (y/n)");
		char ch=sc.next().charAt(0);
		String extraCheese="No";
		if(ch=='y' || ch=='Y')
		{
			extraCheese="Yes";
			price+=50;
		}
		System.out.println("Enter the Quantity");
		int quantity=sc.nextInt();
		int totalprice=price*quantity;
		PizzaOrder order=new PizzaOrder(pizzaType,extraCheese,quantity,totalprice);
		pdao.beginTransaction();
		pdao.addOrder(order);
		//em.persist(login);
		pdao.commitTransaction();
		System.out.println("Successfully Added");
		entityManager.close();
		emf.close();
		
		
		
	}
}
