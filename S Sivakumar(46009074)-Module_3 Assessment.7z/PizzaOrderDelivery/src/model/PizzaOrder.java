package model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="PizzaOrder")
public class PizzaOrder implements Serializable{
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
@Column(name = "orderId")
private int orderId;
private String pizzaType;
private String extraCheese;
private int quantity;
private int totalPrice;
public PizzaOrder() {
	super();
	
}
public PizzaOrder(String pizzaType, String extraCheese, int quantity, int totalPrice) {
	super();
	
	this.pizzaType = pizzaType;
	this.extraCheese = extraCheese;
	this.quantity = quantity;
	this.totalPrice = totalPrice;
}
public int getOrderId() {
	return orderId;
}
public void setOrderId(int orderId) {
	this.orderId = orderId;
}
public String getPizzaType() {
	return pizzaType;
}
public void setPizzaType(String pizzaType) {
	this.pizzaType = pizzaType;
}
public String isExtraCheese() {
	return extraCheese;
}
public void setExtraCheese(String extraCheese) {
	this.extraCheese = extraCheese;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public int getTotalPrice() {
	return totalPrice;
}
public void setTotalPrice(int totalPrice) {
	this.totalPrice = totalPrice;
}

}
