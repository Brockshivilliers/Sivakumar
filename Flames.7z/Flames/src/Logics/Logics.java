package Logics;

public class Logics {
	public int findRemainingLength(String name1, String name2) {
		int length = 0;
		StringBuilder sb1 = new StringBuilder(name1);
		StringBuilder sb2 = new StringBuilder(name2);
		for (int i = 0; i < sb1.length(); i++) {
			for (int j = 0; j < sb2.length(); j++) {
				if (sb1.charAt(i) == sb2.charAt(j)) {
					sb1.delete(i, i + 1);
					sb2.delete(j, j + 1);
					i = -1;
					break;
				}
			}
		}
		length = sb1.length() + sb2.length();
		return length;
	}

	public char findCharacter(int length) {
		int count = 1;
		char ch = 'F';
		StringBuilder flames = new StringBuilder("FLAMES");
		for (int i = 0; i < flames.length(); i++) {
			if (count > 10) {
				break;
			} else if (flames.length() == 1) {
				break;
			} else if (i == flames.length() - 1 && count != length) {
				i = -1;
				count++;
			} else {
				if (count == length) {
					flames.delete(i, i + 1);
					i = i - 1;
					count = 1;
					if ((i + 1) == flames.length() || (i == flames.length() - 1)) {
						i = -1;
					}
				} else {
					count++;
				}
			}
		}
		ch = flames.charAt(0);
		return ch;
	}

	public String findRelationship(char letter, String name2) {
		String relationship = "";
		switch (letter) {
		case 'F':
			relationship = "Congrats " + name2 + " is your Friend";
			break;
		case 'L':
			relationship = "Congrats " + name2 + " is Your Lover And U Guys Loves Each Other";
			break;
		case 'A':
			relationship = "Congrats U Both Guys Had An Affection With Each Others";
			break;
		case 'M':
			relationship = "Congrats U Guys Will Marry And " + name2 + " is ur Life Partner";
			break;
		case 'E':
			relationship = name2 + " is Your Enemy Be Carefull With Him/Her";
			break;
		case 'S':
			relationship = name2 + " is Your Sister/Brother ";
			break;
		default:
			break;
		}
		return relationship;

	}
}
