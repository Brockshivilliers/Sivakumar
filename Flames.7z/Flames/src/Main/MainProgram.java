package Main;

import java.util.InputMismatchException;
import java.util.Scanner;

import Logics.Logics;

public class MainProgram {
	public static void main(String[] args) {
		Logics logics = new Logics();
		Scanner scanner = new Scanner(System.in);
		System.out.println("WELCOME TO RELATIONSHIP FINDER");
		while (true) {
			System.out.println("LET'S FIND THE RELATIONSHIP WITH UR PARTNER");
			System.out.println("Enter Your Name");
			String name1 = scanner.nextLine();
			String modifiedName1 = name1.trim();
			modifiedName1 = modifiedName1.toLowerCase();
			System.out.println("Enter Your Partner Name");
			String name2 = scanner.nextLine();
			String modifiedName2 = name2.trim();
			modifiedName2 = modifiedName2.toLowerCase();
			if (name1.length() > 0 && name2.length() > 0) {
				int remainingLength = logics.findRemainingLength(modifiedName1, modifiedName2);
				char letter = logics.findCharacter(remainingLength);
				String relationship = logics.findRelationship(letter, name2);
				System.out.println(relationship);
				System.out.println("Do You Want To continue ");
				System.out.println("1.yes");
				System.out.println("2.no");
				int ch = 0;
				try {
					ch = scanner.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("Enter Only Integers 1 or 2");
				}
				scanner.nextLine();
				if (ch == 2) {
					break;
				} else if (ch == 1) {
					continue;
				} else {
					System.out.println("Enter Only 1 or 2");
				}
			} else {
				System.out.println("Names Should not be Empty");
			}
		}
		System.out.println("Thank You");
	}
}
