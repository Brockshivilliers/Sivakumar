package quoteGen.service;

import java.util.List;

import quoteGen.bean.AccountCreationClass;
import quoteGen.bean.PolicyCreationClass;
import quoteGen.bean.PolicyDetailsClass;
import quoteGen.bean.ProfileClass;
import quoteGen.dao.InsuranceDaoImplement;
import quoteGen.dao.InsuranceDaoInterface;
import quoteGen.exception.InsuranceException;

public class ServiceImplement implements ServiceInterface {

	InsuranceDaoInterface dao = new InsuranceDaoImplement();

	@Override
	public boolean checkUser(String userName) throws InsuranceException {

		return dao.checkUser(userName);

	}

	@Override
	public boolean userNameVal(String userName) {
		boolean b = false;
		if (Character.isUpperCase(userName.charAt(0))) {
			b = true;
		}
		return b;
	}

	@Override
	public boolean checkUser(String userName, String password) throws InsuranceException {

		return dao.checkUser(userName, password);

	}

	@Override
	public String getRole(String userName) throws InsuranceException {
		return dao.getRole(userName);
	}

	@Override
	public boolean passwordVal(String password) throws InsuranceException {
		boolean b = false;
		boolean lower = false, upper = false, number = false;
		for (int i = 0; i < password.length(); i++) {
			if (Character.isLowerCase(password.charAt(i))) {
				lower = true;
			} else if (Character.isUpperCase(password.charAt(i))) {
				upper = true;
			} else if (Character.isDigit(password.charAt(i))) {
				number = true;
			}
		}
		if (lower && upper && number) {
			b = true;
		} else {
			throw new InsuranceException("Password Doesn't Meet The Certain Requirements");
		}
		return b;
	}

	@Override
	public void addProfile(ProfileClass profile) throws InsuranceException {
		dao.addProfile(profile);
	}

	@Override
	public boolean valFields(AccountCreationClass account) throws InsuranceException {
		boolean b = false;
		if ((Character.isUpperCase(account.getInsuredName().charAt(0)))
				&& (Character.isUpperCase(account.getInsuredStreet().charAt(0)))
				&& (Character.isUpperCase(account.getInsuredCity().charAt(0)))
				&& (Character.isUpperCase(account.getInsuredState().charAt(0)))
				&& (Integer.toString(account.getInsuredZip()).length() == 5)) {
			b = true;
		} else {
			b = false;
		}
		return b;
	}

	@Override
	public int getAccountNumber(AccountCreationClass account) throws InsuranceException {
		return dao.getAccountNumber(account);
	}

	@Override
	public String getBusSeg(int accNum) throws InsuranceException {
		return dao.getBusSeg(accNum);
	}

	@Override
	public String getBusSegId(String busSeg) throws InsuranceException {
		return dao.getBusSegId(busSeg);
	}

	@Override
	public List<String> getQuesIdList(String busSegId) throws InsuranceException {
		return dao.getQuesIdList(busSegId);
	}

	@Override
	public String getQuesDes(String quesId) throws InsuranceException {
		return dao.getQuesDes(quesId);
	}

	@Override
	public List<String> getAnswersList(String quesId) throws InsuranceException {
		return dao.getAnswersList(quesId);
	}

	@Override
	public int addPolicy(PolicyCreationClass policy) throws InsuranceException {
		return dao.addPolicy(policy);
	}

	@Override
	public void addPolicyDetails(PolicyDetailsClass policy) throws InsuranceException {
		dao.addPolicyDetails(policy);
	}

	@Override
	public List<PolicyCreationClass> getAllPolicy() throws InsuranceException {
		return dao.getAllPolicy();
	}

	@Override
	public List<Integer> getAccountNum(String userName) throws InsuranceException {
		return dao.getAccountNum(userName);
	}

	@Override
	public List<PolicyCreationClass> getAllPolicy(int accNum) throws InsuranceException {
		return dao.getAllPolicy(accNum);
	}

	@Override
	public int getAccountNumInsured(String userName) throws InsuranceException {
		return dao.getAccountNumInsured(userName);
	}

	@Override
	public AccountCreationClass getAccountDetails(int accNum) throws InsuranceException {
		return dao.getAccountDetails(accNum);
	}

	@Override
	public PolicyCreationClass getPolicy(int accNum) throws InsuranceException {
		return dao.getPolicy(accNum);
	}

	@Override
	public List<PolicyDetailsClass> getPolicyDetails(int policyNum) throws InsuranceException {
		return dao.getPolicyDetails(policyNum);
	}
}
