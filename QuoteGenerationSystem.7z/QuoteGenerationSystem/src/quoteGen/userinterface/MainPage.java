package quoteGen.userinterface;

import java.util.Scanner;

import quoteGen.exception.InsuranceException;
import quoteGen.service.ServiceImplement;
import quoteGen.service.ServiceInterface;

public class MainPage {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		AdminPage adminPage = new AdminPage();
		InsuredPage insuredPage = new InsuredPage();
		AgentPage agentPage = new AgentPage();
		ServiceInterface service = new ServiceImplement();
		System.out.println("**************************************************");
		System.out.println("*****Welcome To The Quote Generation System*******");
		System.out.println("**************************************************");
		System.out.println();
		System.out.println("**********Login Page*****************");
		System.out.println();
		String userName;
		String password;
		boolean check = false;
		boolean flag = false;
		String role = null;
		char choice;
		do {

			System.out.println("Enter the User Name:");

			userName = scanner.next();

			System.out.println("Enter the Password");

			password = scanner.next();
			try {
				check = service.checkUser(userName, password);
			} catch (InsuranceException e) {
				System.out.println(e.getMessage());
				System.out.println();
			}
			if (check == true) {
				try {
					role = service.getRole(userName);

				} catch (InsuranceException e) {
					System.out.println(e.getMessage());
				}
				if (role.equals("Admin")) {
					adminPage.login(userName);
				} else if (role.equals("Insured")) {
					insuredPage.login(userName);
				} else {
					agentPage.login(userName);
				}
				flag = false;
			} else {
				System.out.println("Your User Name or Password Doesn't Match");
				System.out.println();
				System.out.println("Do You Want Continue Or No (y/n)");
				choice = scanner.next().charAt(0);
				if ((choice == 'y') || (choice == 'Y')) {
					flag = true;
				} else if ((choice == 'n') || (choice == 'N')) {
					System.out.println("Thanks For Using");
					flag = false;
				}

			}

		} while (flag);

	}

}
