package quoteGen.userinterface;

import java.util.List;
import java.util.Scanner;

import quoteGen.bean.PolicyCreationClass;
import quoteGen.exception.InsuranceException;
import quoteGen.service.ServiceImplement;
import quoteGen.service.ServiceInterface;

public class ViewPolicyPage {
	public void viewPolicy(String userName) {
		Scanner scanner = new Scanner(System.in);
		int accountNum = 0;
		ServiceInterface service = new ServiceImplement();
		List<PolicyCreationClass> list = null;
		System.out.println("*********Welcome To the View Policy Page***********");
		try {
			String role = service.getRole(userName);
			if (role.equals("Admin")) {
				list = service.getAllPolicy();
			} else if (role.equals("Agent")) {
				List<Integer> accNumList = null;
				accNumList = service.getAccountNum(userName);
				for (int i = 0; i < accNumList.size(); i++) {
					list = service.getAllPolicy(accNumList.get(i));
				}
			} else {
				accountNum = service.getAccountNumInsured(userName);
				list = service.getAllPolicy(accountNum);
			}
			for (int i = 0; i < list.size(); i++) {
				PolicyCreationClass policy = list.get(i);
				System.out.println("Policy Number:" + policy.getPolicyNumber()+" "+"Policy Premium:" + policy.getPolicyPremium()+" "+"Account Number:" + policy.getAccountNumber());
			}

		}

		catch (InsuranceException e) {
			System.err.println(e.getMessage());
		}
	}

}
