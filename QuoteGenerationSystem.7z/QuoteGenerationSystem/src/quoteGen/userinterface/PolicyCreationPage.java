package quoteGen.userinterface;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import quoteGen.bean.PolicyCreationClass;
import quoteGen.bean.PolicyDetailsClass;
import quoteGen.exception.InsuranceException;
import quoteGen.service.ServiceImplement;
import quoteGen.service.ServiceInterface;

import java.util.Scanner;
import java.util.Set;

public class PolicyCreationPage {
	public void policyCreation() {
		Scanner scanner = new Scanner(System.in);
		ServiceInterface service = new ServiceImplement();
		int accountNum = 0, policyPremium = 0, policyNum = 0, answer = 0;
		String busSeg = null, busSegId = null, quesDes = null;
		List<String> quesIdList = null;
		List<String> answersList = null;
		Map<String, String> quesIdAnswers = new HashMap<String, String>();
		System.out.println("********Welcome To The Policy Creation********");
		System.out.println("Enter The Account Number For Policy Creation:");
		accountNum = scanner.nextInt();
		String selectAns = null;
		try {
			busSeg = service.getBusSeg(accountNum);
			busSegId = service.getBusSegId(busSeg);
			quesIdList = service.getQuesIdList(busSegId);
			for (int i = 0; i < quesIdList.size(); i++) {
				quesDes = service.getQuesDes(quesIdList.get(i));
				System.out.println(quesDes);
				answersList = service.getAnswersList(quesIdList.get(i));
				for (int j = 0; j < answersList.size(); j++) {
					System.out.println((j + 1) + " " + answersList.get(j));
				}
				answer = scanner.nextInt();

				if (answer == 1) {
					selectAns = answersList.get(0);
					policyPremium += 200;

				} else if (answer == 2) {
					selectAns = answersList.get(1);
					policyPremium += 400;
				} else {
					selectAns = answersList.get(2);
					policyPremium += 600;
				}
				quesIdAnswers.put(quesIdList.get(i), selectAns);

			}
			PolicyCreationClass policy = new PolicyCreationClass(policyPremium, accountNum);

			policyNum = service.addPolicy(policy);
			System.out.println("Your Policy Number is" + policyNum);
			Set<Entry<String, String>> set = quesIdAnswers.entrySet();
			for (Map.Entry<String, String> iterator : set) {
				PolicyDetailsClass policyDetails = new PolicyDetailsClass(policyNum, iterator.getKey(),
						iterator.getValue());
				service.addPolicyDetails(policyDetails);

			}
			System.out.println("Your Policy Premium is" + policyPremium);
		} catch (InsuranceException e) {
			System.out.println(e.getMessage());
		}
	}
}
