package quoteGen.userinterface;

import java.util.InputMismatchException;
import java.util.Scanner;

import quoteGen.bean.ProfileClass;
import quoteGen.exception.InsuranceException;
import quoteGen.service.ServiceImplement;
import quoteGen.service.ServiceInterface;

public class ProfileCreationPage {
	public void profileCreation() {

		Scanner scanner = new Scanner(System.in);
		ServiceInterface service = new ServiceImplement();
		boolean flag = false;
		String userName = null;
		String password = null;
		String role = null;
		char choice;
		int choice2 = 0;
		boolean userValid = false;
		boolean pwdValid = false;
		System.out.println("*********Welcome To the Profile Creation Page***********");
		do {
			System.out.println("Enter The User Name(User Name Should Be Unique):");
			userName = scanner.next();
			if (!service.userNameVal(userName)) {
				System.out.println("The UserName is Begins With UpperCase");
				flag = true;
			} else {
				try {
					userValid = service.checkUser(userName);
				} catch (InsuranceException e) {
					System.out.println(e.getMessage());
				}
				if (!userValid) {
					System.out.println("The UserName Is already In Database So Try Another Name");
					System.out.println("Do you want to Continue press y");
					choice = scanner.next().charAt(0);
					if (choice == 'y' || choice == 'Y') {
						flag = true;
					} else {
						System.out.println("Thanks for Using");
						flag = false;
					}
				} else {
					System.out.println(
							"Enter The Password(Password Should Contains Atleast One UpperCase And One LowerCase And One Digit)");
					password = scanner.next();
					try {
						pwdValid = service.passwordVal(password);
					} catch (InsuranceException e) {
						System.out.println(e.getMessage());
						System.out.println("Do you Want To Continue press y");
						choice = scanner.next().charAt(0);
						if (choice == 'y' || choice == 'Y') {
							flag = true;
						} else {
							System.out.println("Thanks for Using");
							flag = false;
						}
					}
					if (pwdValid) {
						System.out.println("Select The Role");
						System.out.println("1.Insured");
						System.out.println("2.Agent");
						try {
							choice2 = scanner.nextInt();
						} catch (InputMismatchException e) {
							System.out.println("Enter only Numbers");
							break;
						}
						if (choice2 == 1) {
							role = "Insured";
							flag = false;
						} else if (choice2 == 2) {
							role = "Agent";
							flag = false;
						} else {
							System.out.println("Please Select a 1 or 2");
							flag = true;
						}
					}
				}
			}
		} while (flag);
		if (userName != null && password != null && role != null) {
			try {
				ProfileClass profile = new ProfileClass(userName, password, role);
				service.addProfile(profile);
				System.out.println("Successfully Data Saved");
			} catch (InsuranceException e) {
				System.out.println(e.getMessage()+"Unable To Save The Data");
			}
		}
	}

}
