package quoteGen.userinterface;

import java.util.InputMismatchException;
import java.util.Scanner;

import quoteGen.bean.AccountCreationClass;
import quoteGen.exception.InsuranceException;
import quoteGen.service.ServiceImplement;
import quoteGen.service.ServiceInterface;

public class AccountCreationPage {

	public void accountCreation(String createdUserName) {
		Scanner scanner = new Scanner(System.in);
		ServiceInterface service = new ServiceImplement();
		String insuredUserName = null;
		int accountNum = 0;
		String insuredName = null;
		String insuredStreet = null;
		String insuredCity = null;
		String insuredState = null;
		int insuredZip = 0;
		String insuredBusinessSegment = null;
		String role = null;
		int choice = 0;
		char choice2;
		System.out.println("*********Welcome To the Account Creation Page***********");
		boolean flag = false;
		do {

			try {
				if (service.getRole(createdUserName).equals("Insured")) {
					insuredUserName = createdUserName;
				} else {
					System.out.println("Enter The Insured UserName");
					insuredUserName = scanner.next();
					role = service.getRole(insuredUserName);
				}
				try {
					service.getAccountNumInsured(insuredUserName);
					System.out.println("You Already Created Account For this Insured");
					break;
				} catch (InsuranceException e) {
					System.out.println("Enter The Insured Name(First Letter Should Be UpperCase)");
					insuredName = scanner.next();
					System.out.println("Enter The Insured Street(First Letter Should Be UpperCase)");
					insuredStreet = scanner.next();
					System.out.println("Enter The Insured City(First Letter Should Be UpperCase)");
					insuredCity = scanner.next();
					System.out.println("Enter The Insured State(First Letter Should Be UpperCase)");
					insuredState = scanner.next();
					System.out.println("Enter The Insured ZIP(Should Be 5 Digit)");
					insuredZip = scanner.nextInt();
					System.out.println("Select The Line of Buisness");
					System.out.println("1.Buisness Auto");
					System.out.println("2.Restaurent");
					try {
						choice = scanner.nextInt();
					} catch (InputMismatchException exception) {
						System.out.println(exception);
					}
					if (choice == 1) {
						insuredBusinessSegment = "Business Auto";
					} else if (choice == 2) {
						insuredBusinessSegment = "Restaurant";
					}
					AccountCreationClass account = new AccountCreationClass(insuredName, insuredStreet, insuredCity,
							insuredState, insuredZip, insuredBusinessSegment, insuredUserName, createdUserName);

					if (service.valFields(account)) {

						accountNum = service.getAccountNumber(account);
						System.out.println("Your Account Number is" + " " + accountNum);
						flag = false;
					} else {
						System.err.println("The Fields Are Not Meet The Certain Requirements");
						flag = true;
					}
				}

			} catch (InsuranceException e) {
				System.out.println(e.getMessage());
				flag = true;
			} catch (InputMismatchException e) {
				System.out.println(e);
				flag=true;
			}

		} while (flag);

	}
}
