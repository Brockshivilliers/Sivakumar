package quoteGen.userinterface;

import java.util.List;
import java.util.Scanner;

import quoteGen.bean.AccountCreationClass;
import quoteGen.bean.PolicyCreationClass;
import quoteGen.bean.PolicyDetailsClass;
import quoteGen.exception.InsuranceException;
import quoteGen.service.ServiceImplement;
import quoteGen.service.ServiceInterface;

public class ReportGenerationPage {
	public void reportGeneration() {
		Scanner scanner = new Scanner(System.in);
		ServiceInterface service = new ServiceImplement();
		System.out.println("*********Welcome To the Report Generation Page***********");
		System.out.println("Enter The User Name:");
		String userName = scanner.next();
		try {
			int accountNum = service.getAccountNumInsured(userName);
			System.out.println(accountNum);
			AccountCreationClass account = null;
			account = service.getAccountDetails(accountNum);
			System.out.println("Insured Name:" + account.getInsuredName());
			System.out.println("Insured Street:" + account.getInsuredStreet());
			System.out.println("Insured City:" + account.getInsuredCity());
			System.out.println("Insured State:" + account.getInsuredState());
			System.out.println("Insured Zip:" + account.getInsuredZip());
			System.out.println("Insured Business Segment:" + account.getBusinessSegment());
			PolicyCreationClass policy = null;
			policy = service.getPolicy(accountNum);
			int policyNumber = policy.getPolicyNumber();
			System.out.println("Policy Number:" + policyNumber);
			System.out.println("Policy Premium:" + policy.getPolicyPremium());
			PolicyDetailsClass policyDetails = null;
			List<PolicyDetailsClass> list = null;
			list = service.getPolicyDetails(policyNumber);
			for (int i = 0; i < list.size(); i++) {
				policyDetails = list.get(i);
				System.out.println("QuestionId:" + policyDetails.getQuesId());
				System.out.println("Answer:" + policyDetails.getAns());
			}

		} catch (InsuranceException e) {
			System.err.println(e.getMessage());
		}
	}
}
