package quoteGen.userinterface;

import java.util.InputMismatchException;
import java.util.Scanner;

public class AdminPage {

	public void login(String userName) {
		Scanner scanner = new Scanner(System.in);
		boolean flag = false;
		char choice2;
		int choice = 0;
		System.out.println("***************Loged In As Admin*********************");
		System.out.println();
		System.out.println();
		do {
			System.out.println("1.Profile Creation");
			System.out.println("2.Account Creation");
			System.out.println("3.Policy Creation");
			System.out.println("4.View Policy");
			System.out.println("5.Report Generation");
			System.out.println("Enter choice: ");
			try {
				choice = scanner.nextInt();
			} catch (InputMismatchException e) {
				System.out.println("Enter The Digits");
				break;
			}
			switch (choice) {
			case 1: {
				ProfileCreationPage profileCreate = new ProfileCreationPage();
				profileCreate.profileCreation();
				break;
			}
			case 2: {
				AccountCreationPage accountCreate = new AccountCreationPage();
				accountCreate.accountCreation(userName);
				break;
			}
			case 3: {
				PolicyCreationPage policyCreate = new PolicyCreationPage();
				policyCreate.policyCreation();
				break;
			}
			case 4: {
				ViewPolicyPage viewPolicy = new ViewPolicyPage();
				viewPolicy.viewPolicy(userName);
				break;
			}
			case 5: {
				ReportGenerationPage reportGeneration = new ReportGenerationPage();
				reportGeneration.reportGeneration();
				break;
			}
			default: {
				System.out.println("Enter the Number Between 1-5");
				flag=true;
			}
			}

			System.out.println("Do You Want To Continue (y/n)");
			choice2 = scanner.next().charAt(0);
			if (choice2 == 'y' || choice2 == 'Y') {
				flag = true;
			} else {
				System.out.println("Thanks For Using");
				flag = false;
			}
		} while (flag);
		
		scanner.close();
		
	}

}
