package quoteGen.exception;

public class InsuranceException extends Exception{

	public InsuranceException() {
		super();
		
	}

	public InsuranceException(String message) {
		super(message);
		
	}

}
