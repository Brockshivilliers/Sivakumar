package quoteGen.utility;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;

import quoteGen.exception.InsuranceException;

public class JdbcUtility {
	public static Connection getConnection() throws InsuranceException
	{
		Driver driver=new oracle.jdbc.OracleDriver();
		Connection con=null;
		try {
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","sivas","sivas");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new InsuranceException("Unable to Execute Statement");
		}
		return con;
	}
}
