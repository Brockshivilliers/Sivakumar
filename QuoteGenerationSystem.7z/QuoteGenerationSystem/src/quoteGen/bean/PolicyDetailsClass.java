package quoteGen.bean;

public class PolicyDetailsClass {
private int policyNum;
private String quesId;
private String ans;
public PolicyDetailsClass() {
	super();
	// TODO Auto-generated constructor stub
}
public PolicyDetailsClass(int policyNum, String quesId, String ans) {
	super();
	this.policyNum = policyNum;
	this.quesId = quesId;
	this.ans = ans;
}
public int getPolicyNum() {
	return policyNum;
}
public void setPolicyNum(int policyNum) {
	this.policyNum = policyNum;
}
public String getQuesId() {
	return quesId;
}
public void setQuesId(String quesId) {
	this.quesId = quesId;
}
public String getAns() {
	return ans;
}
public void setAns(String ans) {
	this.ans = ans;
}
@Override
public String toString() {
	return "PolicyDetails [policyNum=" + policyNum + ", quesId=" + quesId + ", ans=" + ans + "]";
}

}
