package quoteGen.bean;

public class PolicyCreationClass {
	private int policyNumber;
	private int policyPremium;
	private int accountNumber;
	public PolicyCreationClass() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public PolicyCreationClass(int policyNumber, int policyPremium, int accountNumber) {
		super();
		this.policyNumber = policyNumber;
		this.policyPremium = policyPremium;
		this.accountNumber = accountNumber;
	}

	public PolicyCreationClass(int policyPremium, int accountNumber) {
		super();
		this.policyPremium = policyPremium;
		this.accountNumber = accountNumber;
	}
	public int getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(int policyNumber) {
		this.policyNumber = policyNumber;
	}
	public int getPolicyPremium() {
		return policyPremium;
	}
	public void setPolicyPremium(int policyPremium) {
		this.policyPremium = policyPremium;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	@Override
	public String toString() {
		return "PolicyCreationClass [policyNumber=" + policyNumber + ", policyPremium=" + policyPremium
				+ ", accountNumber=" + accountNumber + "]";
	}
	
}
