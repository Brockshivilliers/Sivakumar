package quoteGen.dao;

import java.util.List;

import quoteGen.bean.AccountCreationClass;
import quoteGen.bean.PolicyCreationClass;
import quoteGen.bean.PolicyDetailsClass;
import quoteGen.bean.ProfileClass;
import quoteGen.exception.InsuranceException;

public interface InsuranceDaoInterface {
	public boolean checkUser(String userName) throws InsuranceException;

	public boolean checkUser(String userName, String password) throws InsuranceException;

	public String getRole(String userName) throws InsuranceException;

	public void addProfile(ProfileClass profile) throws InsuranceException;

	public int getAccountNumber(AccountCreationClass ac) throws InsuranceException;

	public String getBusSeg(int accNum) throws InsuranceException;

	public String getBusSegId(String busSeg) throws InsuranceException;

	public List<String> getQuesIdList(String busSegId) throws InsuranceException;

	public String getQuesDes(String quesId) throws InsuranceException;

	public List<String> getAnswersList(String quesId) throws InsuranceException;

	public int addPolicy(PolicyCreationClass policy) throws InsuranceException;

	public void addPolicyDetails(PolicyDetailsClass policy) throws InsuranceException;

	public List<PolicyCreationClass> getAllPolicy() throws InsuranceException;

	public List<Integer> getAccountNum(String userName) throws InsuranceException;

	public List<PolicyCreationClass> getAllPolicy(int accNum) throws InsuranceException;

	public int getAccountNumInsured(String userName) throws InsuranceException;

	public AccountCreationClass getAccountDetails(int accNum) throws InsuranceException;

	public PolicyCreationClass getPolicy(int accNum) throws InsuranceException;

	public List<PolicyDetailsClass> getPolicyDetails(int policyNum) throws InsuranceException;
}
