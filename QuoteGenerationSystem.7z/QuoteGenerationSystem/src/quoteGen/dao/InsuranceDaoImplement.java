package quoteGen.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import quoteGen.bean.AccountCreationClass;
import quoteGen.bean.PolicyCreationClass;
import quoteGen.bean.PolicyDetailsClass;
import quoteGen.exception.InsuranceException;
import quoteGen.utility.JdbcUtility;

public class InsuranceDaoImplement implements InsuranceDaoInterface {

	JdbcUtility jdbc = new JdbcUtility();

	@Override
	public boolean checkUser(String userName) throws InsuranceException {
		boolean b = false;
		String uname = null;
		try {
			Connection con = jdbc.getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT * FROM USER_ROLE WHERE USER_NAME=?");
			ps.setString(1, userName);
			try {
				ResultSet rs = ps.executeQuery();
				rs.next();
				uname = rs.getString(1);
			} catch (SQLException e) {
				b = true;
			}

			if (uname != null) {
				b = false;
			}

			con.close();
		} catch (SQLException e) {
			throw new InsuranceException("Unable to Execute Statement");
		}
		return b;
	}

	@Override
	public boolean checkUser(String userName, String password) throws InsuranceException {
		boolean b = false;
		String pwd = null;
		try {
			Connection con = jdbc.getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT * FROM USER_ROLE WHERE USER_NAME=?");
			ps.setString(1, userName);
			ResultSet rs = ps.executeQuery();
			rs.next();
			pwd = rs.getString(2);
			System.out.println(pwd);
			if (password.equals(pwd)) {
				b = true;
			} else {
				b = false;
			}
			con.close();
		} catch (SQLException e) {
			throw new InsuranceException("Unable to Execute Statement");
		}
		return b;
	}

	@Override
	public String getRole(String userName) throws InsuranceException {
		String role = null;
		try {
			Connection con = jdbc.getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT * FROM USER_ROLE WHERE USER_NAME=?");
			ps.setString(1, userName);
			ResultSet rs = ps.executeQuery();
			rs.next();
			role = rs.getString(3);

			con.close();
		} catch (SQLException e) {
			throw new InsuranceException("Unable to Execute Statement");
		}
		return role;
	}

	@Override
	public void addProfile(quoteGen.bean.ProfileClass profile) throws InsuranceException {
		try {
			Connection con = jdbc.getConnection();
			PreparedStatement ps = con.prepareStatement("INSERT INTO USER_ROLE VALUES(?,?,?)");
			ps.setString(1, profile.getUserName());
			ps.setString(2, profile.getPassword());
			ps.setString(3, profile.getRole());
			ps.executeUpdate();

			con.close();
		} catch (SQLException e) {
			throw new InsuranceException("Unable to Execute Statement");
		}
	}

	@Override
	public int getAccountNumber(AccountCreationClass account) throws InsuranceException {

		int accno = 0;
		try {
			Connection con = jdbc.getConnection();

			PreparedStatement ps = con.prepareStatement("INSERT INTO Accounts VALUES(acc_seq.nextval,?,?,?,?,?,?,?,?)");

			ps.setString(1, account.getInsuredName());
			ps.setString(2, account.getInsuredStreet());
			ps.setString(3, account.getInsuredCity());
			ps.setString(4, account.getInsuredState());
			ps.setInt(5, account.getInsuredZip());
			ps.setString(6, account.getBusinessSegment());
			ps.setString(7, account.getInusredUserName());
			ps.setString(8, account.getCreatedUserName());
			ps.executeUpdate();
			ps = con.prepareStatement("select acc_seq.currval from dual");
			ResultSet rs = ps.executeQuery();
			rs.next();
			accno = rs.getInt(1);
			System.out.println(accno);
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

		return accno;
	}

	@Override
	public String getBusSeg(int accNum) throws InsuranceException {
		String busSeg = null;
		try {
			Connection con = jdbc.getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT * FROM accounts WHERE account_number=?");
			ps.setInt(1, accNum);
			ResultSet rs = ps.executeQuery();
			rs.next();
			busSeg = rs.getString(7);

			con.close();
		} catch (SQLException e) {
			throw new InsuranceException("Unable to Execute Statement");
		}
		return busSeg;
	}

	@Override
	public String getBusSegId(String busSeg) throws InsuranceException {
		String busSegId = null;
		try {
			Connection con = jdbc.getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT * FROM business_segment WHERE BUS_SEG_NAME=?");
			ps.setString(1, busSeg);
			ResultSet rs = ps.executeQuery();
			rs.next();
			busSegId = rs.getString(1);

			con.close();
		} catch (SQLException e) {
			throw new InsuranceException("Unable to Execute Statement");
		}
		return busSegId;
	}

	@Override
	public List<String> getQuesIdList(String busSegId) throws InsuranceException {
		List<String> questionList = new ArrayList<String>();

		try {
			Connection con = jdbc.getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT * from policy_questions WHERE BUS_SEG_ID=?");
			ps.setString(1, busSegId);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				questionList.add(rs.getString(1));
			}
			con.close();
		} catch (SQLException e) {
			throw new InsuranceException("Unable to Execute Statement");
		}
		return questionList;
	}

	@Override
	public String getQuesDes(String quesId) throws InsuranceException {
		String quesDes = null;
		try {
			Connection con = jdbc.getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT * from policy_questions WHERE POL_QUES_ID=?");
			ps.setString(1, quesId);
			ResultSet rs = ps.executeQuery();
			rs.next();
			quesDes = rs.getString(4);

			con.close();
		} catch (SQLException e) {
			throw new InsuranceException("Unable to Execute Statement");
		}
		return quesDes;
	}

	@Override
	public List<String> getAnswersList(String quesId) throws InsuranceException {
		List<String> answersList = new ArrayList<String>();

		try {
			Connection con = jdbc.getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT * from policy_questions WHERE POL_QUES_ID=?");
			ps.setString(1, quesId);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				answersList.add(rs.getString(5));
				answersList.add(rs.getString(7));
				answersList.add(rs.getString(9));
			}
			con.close();
		} catch (SQLException e) {
			throw new InsuranceException("Unable to Execute Statement");
		}
		return answersList;
	}

	@Override
	public int addPolicy(PolicyCreationClass policy) throws InsuranceException {
		int policyNum = 0;
		try {
			Connection con = jdbc.getConnection();

			PreparedStatement ps = con.prepareStatement("INSERT INTO policy values(policy_number_seq.nextval, ?, ?)");

			ps.setInt(1, policy.getPolicyPremium());
			ps.setInt(2, policy.getAccountNumber());
			ps.executeUpdate();
			ps = con.prepareStatement("select policy_number_seq.currval from dual");
			ResultSet rs = ps.executeQuery();
			rs.next();

			policyNum = rs.getInt(1);
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

		return policyNum;
	}

	@Override
	public void addPolicyDetails(PolicyDetailsClass policy) throws InsuranceException {
		try {
			Connection con = jdbc.getConnection();

			PreparedStatement ps = con.prepareStatement("INSERT INTO policy_details VALUES(?,?,?)");

			ps.setInt(1, policy.getPolicyNum());
			ps.setString(2, policy.getQuesId());
			ps.setString(3, policy.getAns());
			ps.executeUpdate();
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	}

	@Override
	public List<PolicyCreationClass> getAllPolicy() throws InsuranceException {
		List<PolicyCreationClass> viewPolicy = new ArrayList<>();
		try {
			Connection con = jdbc.getConnection();

			PreparedStatement ps = con.prepareStatement("SELECT * FROM policy");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int policyNumber = rs.getInt(1);
				int policyPremium = rs.getInt(2);
				int accountNumber = rs.getInt(3);
				PolicyCreationClass policy = new PolicyCreationClass(policyNumber, policyPremium, accountNumber);
				viewPolicy.add(policy);
			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}
		return viewPolicy;
	}

	@Override
	public List<Integer> getAccountNum(String userName) throws InsuranceException {
		List<Integer> accNum = new ArrayList<Integer>();
		try {
			Connection con = jdbc.getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT * from accounts WHERE CREATED_BY=?");
			ps.setString(1, userName);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				accNum.add(rs.getInt(1));
				System.out.println(rs.getInt(1));
			}
			con.close();
		} catch (SQLException e) {
			// System.out.println(e);
			throw new InsuranceException("Unable To execute");
		}
		return accNum;
	}

	@Override
	public List<PolicyCreationClass> getAllPolicy(int accNum) throws InsuranceException {
		List<PolicyCreationClass> viewPolicy = new ArrayList<>();
		try {
			Connection con = jdbc.getConnection();

			PreparedStatement ps = con.prepareStatement("SELECT * FROM policy where ACCOUNT_NUMBER=?");
			ps.setInt(1, accNum);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int policyNumber = rs.getInt(1);
				int policyPremium = rs.getInt(2);
				int accountNumber = rs.getInt(3);
				PolicyCreationClass policy = new PolicyCreationClass(policyNumber, policyPremium, accountNumber);
				viewPolicy.add(policy);
			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}
		return viewPolicy;
	}

	@Override
	public int getAccountNumInsured(String userName) throws InsuranceException {
		int accNum = 0;
		try {
			Connection con = jdbc.getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT * from accounts WHERE USER_NAME=?");
			ps.setString(1, userName);
			ResultSet rs = ps.executeQuery();
			rs.next();
			accNum = rs.getInt(1);

			con.close();
		} catch (SQLException e) {
			throw new InsuranceException("Unable to Execute Statement");
		}
		return accNum;
	}

	@Override
	public AccountCreationClass getAccountDetails(int accNum) throws InsuranceException {
		AccountCreationClass accountDetails = new AccountCreationClass();
		try {
			Connection con = jdbc.getConnection();

			PreparedStatement ps = con.prepareStatement("SELECT * FROM accounts where ACCOUNT_NUMBER=?");
			ps.setInt(1, accNum);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				String insuredName = rs.getString(2);
				String insuredStreet = rs.getString(3);
				String insuredCity = rs.getString(4);
				String insuredState = rs.getString(5);
				int insuredZip = rs.getInt(6);
				String businessSegment = rs.getString(7);
				accountDetails = new AccountCreationClass(insuredName, insuredStreet, insuredCity, insuredState,
						insuredZip, businessSegment);

			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}
		return accountDetails;
	}

	@Override
	public PolicyCreationClass getPolicy(int accNum) throws InsuranceException {
		PolicyCreationClass viewPolicy = null;
		try {
			Connection con = jdbc.getConnection();

			PreparedStatement ps = con.prepareStatement("SELECT * FROM policy where ACCOUNT_NUMBER=?");
			ps.setInt(1, accNum);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int policyNumber = rs.getInt(1);
				int policyPremium = rs.getInt(2);
				int accountNumber = rs.getInt(3);
				viewPolicy = new PolicyCreationClass(policyNumber, policyPremium, accountNumber);
			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}
		return viewPolicy;
	}

	@Override
	public List<PolicyDetailsClass> getPolicyDetails(int policyNum) throws InsuranceException {
		List<PolicyDetailsClass> policyDetails = new ArrayList<>();

		try {
			Connection con = jdbc.getConnection();

			PreparedStatement ps = con.prepareStatement("SELECT * FROM policy_details where POLICY_NUMBER=?");
			ps.setInt(1, policyNum);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int policyNumber = rs.getInt(1);
				String quesId = rs.getString(2);
				String answer = rs.getString(3);
				PolicyDetailsClass details = new PolicyDetailsClass(policyNumber, quesId, answer);
				policyDetails.add(details);
			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}
		return policyDetails;
	}
}
